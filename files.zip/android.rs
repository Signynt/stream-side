// src/backend/android.rs
//
// Android-бекенд: аппаратный HEVC-декодер через NDK AMediaCodec.
//
// ┌─────────────────────────────────────────────────────────────────────┐
// │  АРХИТЕКТУРА ZERO-COPY НА ANDROID                                    │
// │                                                                       │
// │  Kotlin         JNI (этот файл)            NDK MediaCodec            │
// │                                                                       │
// │  SurfaceView ──► ANativeWindow_fromSurface                           │
// │                         │                                            │
// │                         ▼                                            │
// │  VideoPacket  ──► AMediaCodec_queueInputBuffer                       │
// │  (HEVC NAL)              │                                           │
// │                         ▼                                            │
// │                  Hardware decoder                                    │
// │                         │  (НЕТ копии в Rust!)                      │
// │                         ▼                                            │
// │                  AMediaCodec_releaseOutputBuffer(render=true)        │
// │                         │                                            │
// │                         ▼                                            │
// │                  ANativeWindow / SurfaceView  ──► Экран              │
// └─────────────────────────────────────────────────────────────────────┘
//
// Ключевой момент: параметр `render=true` в releaseOutputBuffer —
// именно он "пушит" кадр напрямую в Surface без промежуточных копий.

use std::ffi::CString;
use std::ptr;
use std::sync::{Arc, Mutex};

use jni::{
    objects::{JClass, JObject, JString},
    sys::jint,
    JNIEnv,
};
use once_cell::sync::OnceCell;

use super::{BackendError, FrameOutput, VideoBackend};

// ─────────────────────────────────────────────────────────────────────────────
// Глобальный синглтон бекенда
//
// Нужен потому что JNI-вызовы приходят в разных точках:
//   - initBackend()      — JNI-поток (передача Surface)
//   - startNetworking()  — JNI-поток (старт QUIC)
//   - Сетевой поток      — tokio-поток (push_encoded)
//
// Arc<Mutex<>> даёт потокобезопасный доступ из всех них.
// ─────────────────────────────────────────────────────────────────────────────
static BACKEND: OnceCell<Arc<Mutex<AndroidMediaCodecBackend>>> = OnceCell::new();

fn get_or_create_backend() -> Arc<Mutex<AndroidMediaCodecBackend>> {
    BACKEND
        .get_or_init(|| Arc::new(Mutex::new(AndroidMediaCodecBackend::new())))
        .clone()
}

// ─────────────────────────────────────────────────────────────────────────────
// Внутреннее состояние NDK-объектов
//
// SAFETY: AMediaCodec документирован как thread-safe для одновременного
// доступа к входным и выходным буферам из разных потоков — именно наш случай.
// Тем не менее мы оборачиваем всё в Mutex для упрощения управления состоянием.
// ─────────────────────────────────────────────────────────────────────────────
struct CodecState {
    codec:         *mut ndk_sys::AMediaCodec,
    native_window: *mut ndk_sys::ANativeWindow,
}

// Указатели сами по себе не Send, но по контракту NDK мы гарантируем
// правильный порядок доступа через Mutex.
unsafe impl Send for CodecState {}
unsafe impl Sync for CodecState {}

impl Drop for CodecState {
    fn drop(&mut self) {
        unsafe {
            // Важен порядок: сначала остановить кодек, потом удалить,
            // потом отпустить ANativeWindow.
            ndk_sys::AMediaCodec_stop(self.codec);
            ndk_sys::AMediaCodec_delete(self.codec);
            ndk_sys::ANativeWindow_release(self.native_window);
        }
        log::info!("[MediaCodec] Resources released");
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Основная структура бекенда
// ─────────────────────────────────────────────────────────────────────────────
pub struct AndroidMediaCodecBackend {
    state:        Option<CodecState>,
    frame_pts_us: u64, // монотонно возрастающий PTS (microseconds)
}

impl AndroidMediaCodecBackend {
    pub fn new() -> Self {
        Self {
            state:        None,
            frame_pts_us: 0,
        }
    }

    /// Инициализировать MediaCodec с переданным ANativeWindow.
    ///
    /// # Safety
    /// - `native_window` должен быть получен через `ANativeWindow_fromSurface`.
    /// - Вызывать только пока Surface жив (SurfaceView не уничтожен).
    pub unsafe fn init_with_surface(
        &mut self,
        native_window: *mut ndk_sys::ANativeWindow,
        width:         i32,
        height:        i32,
    ) -> Result<(), BackendError> {
        // Если уже инициализирован — шатдаун перед переинициализацией
        // (например, Surface пересоздался при повороте экрана)
        self.shutdown();

        // ── 1. Создать декодер по MIME-типу ────────────────────────────────
        let mime   = CString::new("video/hevc").unwrap();
        let codec  = ndk_sys::AMediaCodec_createDecoderByType(mime.as_ptr());
        if codec.is_null() {
            return Err(BackendError::ConfigError(
                "AMediaCodec_createDecoderByType(video/hevc) returned null.\
                 Device may not support hardware HEVC decoding.".into()
            ));
        }

        // ── 2. Собрать AMediaFormat ─────────────────────────────────────────
        let format = ndk_sys::AMediaFormat_new();

        // Вспомогательные макросы для краткости
        macro_rules! fmt_str {
            ($k:expr, $v:expr) => {{
                let k = CString::new($k).unwrap();
                let v = CString::new($v).unwrap();
                ndk_sys::AMediaFormat_setString(format, k.as_ptr(), v.as_ptr());
            }};
        }
        macro_rules! fmt_i32 {
            ($k:expr, $v:expr) => {{
                let k = CString::new($k).unwrap();
                ndk_sys::AMediaFormat_setInt32(format, k.as_ptr(), $v);
            }};
        }

        fmt_str!("mime",              "video/hevc");
        fmt_i32!("width",             width);
        fmt_i32!("height",            height);
        // Максимальный размер входного буфера (4 МБ хватает для 1080p HEVC)
        fmt_i32!("max-input-size",    4 * 1024 * 1024);
        // Adaptive playback: кодек выживет при смене разрешения
        // без полного пересоздания (API 19+)
        fmt_i32!("adaptive-playback", 1);

        // ── КЛЮЧЕВЫЕ ПАРАМЕТРЫ НИЗКОЙ ЗАДЕРЖКИ ────────────────────────────
        //
        // low-latency=1 (API 30+): декодер выдаёт кадр сразу, не накапливая
        // буфер для переупорядочивания B-кадров. Для стриминга экрана
        // (без B-кадров) это устраняет pipeline delay ~2-4 кадра.
        fmt_i32!("low-latency",       1);
        //
        // priority=0 (realtime): планировщик повышает приоритет
        // потоков декодера. Критично для достижения <50ms latency.
        fmt_i32!("priority",          0);
        //
        // operating-rate: подсказка декодеру ожидаемый fps.
        // Многие реализации аллоцируют буферы под этот fps.
        fmt_i32!("operating-rate",    60);

        // ── 3. Настроить кодек с Surface ────────────────────────────────────
        //
        // Передача `native_window` сюда — вот где происходит "магия"
        // zero-copy: MediaCodec настраивается на запись напрямую в Surface,
        // минуя любую промежуточную Rust/JVM память.
        //
        // flags=0 → режим декодера (не энкодера)
        let status = ndk_sys::AMediaCodec_configure(
            codec,
            format,
            native_window,
            ptr::null_mut(), // crypto/DRM — не нужно
            0,
        );
        ndk_sys::AMediaFormat_delete(format); // format больше не нужен

        if status != ndk_sys::AMEDIA_OK as i32 {
            ndk_sys::AMediaCodec_delete(codec);
            return Err(BackendError::ConfigError(
                format!("AMediaCodec_configure failed with status={status}")
            ));
        }

        // ── 4. Запустить кодек ──────────────────────────────────────────────
        let status = ndk_sys::AMediaCodec_start(codec);
        if status != ndk_sys::AMEDIA_OK as i32 {
            ndk_sys::AMediaCodec_delete(codec);
            return Err(BackendError::ConfigError(
                format!("AMediaCodec_start failed with status={status}")
            ));
        }

        self.state = Some(CodecState { codec, native_window });
        log::info!("[MediaCodec] Initialized: {width}x{height} HEVC decoder → Surface");
        Ok(())
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Реализация трейта VideoBackend
// ─────────────────────────────────────────────────────────────────────────────

impl VideoBackend for AndroidMediaCodecBackend {
    fn push_encoded(&mut self, payload: &[u8], frame_id: u64) -> Result<(), BackendError> {
        let state = self.state.as_ref().ok_or(BackendError::NotInitialized)?;

        unsafe {
            // Запросить входной буфер (таймаут 5 мс).
            // При переполнении возвращаем BufferFull — сетевой цикл
            // пропустит этот кадр. Это правильное поведение для
            // low-latency стриминга: лучше пропустить кадр, чем блокировать поток.
            let idx = ndk_sys::AMediaCodec_dequeueInputBuffer(state.codec, 5_000);

            if idx == ndk_sys::AMEDIACODEC_INFO_TRY_AGAIN_LATER as isize {
                return Err(BackendError::BufferFull);
            }
            if idx < 0 {
                return Err(BackendError::DecodeError(
                    format!("dequeueInputBuffer error: {idx}")
                ));
            }
            let idx = idx as usize;

            // Получить указатель на входной буфер
            let mut buf_size: usize = 0;
            let buf_ptr = ndk_sys::AMediaCodec_getInputBuffer(
                state.codec, idx, &mut buf_size
            );
            if buf_ptr.is_null() {
                return Err(BackendError::DecodeError("getInputBuffer returned null".into()));
            }

            // Скопировать NAL-данные в буфер декодера.
            // Это единственная копия данных в Android-пути — неизбежна,
            // т.к. QUIC-буфер не может быть напрямую передан в MediaCodec.
            let copy_len = payload.len().min(buf_size);
            ptr::copy_nonoverlapping(payload.as_ptr(), buf_ptr, copy_len);

            // PTS в микросекундах. MediaCodec использует его только для
            // переупорядочивания B-кадров. Поскольку стриминг экрана
            // обычно не содержит B-кадров, подойдёт любой монотонный PTS.
            // Используем frame_id * 16667 µs ≈ 60 fps.
            self.frame_pts_us = frame_id.saturating_mul(16_667);

            let status = ndk_sys::AMediaCodec_queueInputBuffer(
                state.codec,
                idx,
                0,                    // offset внутри буфера
                copy_len,             // реальный размер данных
                self.frame_pts_us,    // PTS
                0,                    // flags (0 = обычный кадр)
            );

            if status != ndk_sys::AMEDIA_OK as i32 {
                return Err(BackendError::DecodeError(
                    format!("queueInputBuffer failed: {status}")
                ));
            }
        }
        Ok(())
    }

    fn poll_output(&mut self) -> Result<FrameOutput, BackendError> {
        let state = self.state.as_ref().ok_or(BackendError::NotInitialized)?;

        unsafe {
            let mut info = ndk_sys::AMediaCodecBufferInfo {
                offset:              0,
                size:                0,
                presentationTimeUs:  0,
                flags:               0,
            };

            // Неблокирующий poll (timeout=0).
            // Если кадр не готов — сразу вернём Pending, без ожидания.
            let idx = ndk_sys::AMediaCodec_dequeueOutputBuffer(
                state.codec, &mut info, 0
            );

            match idx {
                // Кадр ещё не декодирован
                i if i == ndk_sys::AMEDIACODEC_INFO_TRY_AGAIN_LATER as isize => {
                    Ok(FrameOutput::Pending)
                }

                // Изменился формат вывода (нормально при первом кадре)
                i if i == ndk_sys::AMEDIACODEC_INFO_OUTPUT_FORMAT_CHANGED as isize => {
                    log::debug!("[MediaCodec] Output format changed");
                    Ok(FrameOutput::Pending)
                }

                // Кадр готов — ГЛАВНАЯ ОПЕРАЦИЯ ZERO-COPY
                idx if idx >= 0 => {
                    // releaseOutputBuffer(render=true) отправляет декодированный
                    // кадр НАПРЯМУЮ в ANativeWindow/Surface без промежуточных копий.
                    // Именно здесь происходит то, что на десктопе делает WGPU:
                    // вывод на экран. Но без участия Rust-кода рендера.
                    ndk_sys::AMediaCodec_releaseOutputBuffer(
                        state.codec,
                        idx as usize,
                        true, // render = true → push to Surface
                    );
                    Ok(FrameOutput::DirectToSurface)
                }

                _ => Ok(FrameOutput::Pending),
            }
        }
    }

    fn shutdown(&mut self) {
        // CodecState::drop() освобождает всё через RAII
        self.state = None;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// JNI EXPORTS
//
// Эти функции вызываются из Kotlin.
// Соглашение об именовании: Java_<package>_<ClassName>_<methodName>
// ─────────────────────────────────────────────────────────────────────────────

/// Инициализировать MediaCodec с Android Surface.
///
/// Вызывать ПОСЛЕ того, как SurfaceView создан и доступен его Surface.
///
/// # Управление памятью и жизненным циклом
///
/// `surface` — это локальная JNI-ссылка, действительная только в рамках
/// данного JNI-вызова. Мы немедленно конвертируем её в ANativeWindow через
/// `ANativeWindow_fromSurface`, которая добавляет свой ref-count к нативному
/// окну. Поэтому:
/// - Surface-объект на Java-стороне может быть GC'd без последствий.
/// - ANativeWindow будет жить до вызова `ANativeWindow_release` в shutdown().
/// - НЕ нужно сохранять jobject как глобальную JNI-ссылку.
///
/// ВАЖНО: Если Surface уничтожается (Activity pause / экранный поворот),
/// Kotlin ОБЯЗАН вызвать `shutdownBackend()` ДО вызова `surfaceDestroyed`.
/// Иначе AMediaCodec продолжит писать в уничтоженный ANativeWindow → UB.
#[no_mangle]
pub extern "C" fn Java_com_example_streamreceiver_NativeLib_initBackend(
    env:     JNIEnv,
    _class:  JClass,
    surface: JObject,
    width:   jint,
    height:  jint,
) {
    // catch_unwind предотвращает панику от перехода через FFI-границу
    // (UB по стандарту C++ — Kotlin runtime не знает о Rust-паниках)
    let _ = std::panic::catch_unwind(|| {
        // SAFETY: вызов пока `env` (а значит, JNIEnv и Surface) ещё живы
        let native_window = unsafe {
            ndk_sys::ANativeWindow_fromSurface(
                env.get_raw(),
                surface.as_raw() as ndk_sys::jobject,
            )
        };

        if native_window.is_null() {
            log::error!("[JNI] ANativeWindow_fromSurface returned null!");
            return;
        }

        let backend = get_or_create_backend();
        let mut guard = backend.lock().unwrap();

        match unsafe { guard.init_with_surface(native_window, width, height) } {
            Ok(())   => log::info!("[JNI] initBackend OK"),
            Err(e)   => log::error!("[JNI] initBackend failed: {e}"),
        }
    });
}

/// Запустить QUIC-клиент для приёма видеопотока.
///
/// Вызывать ПОСЛЕ `initBackend`. Создаёт отдельный поток с tokio-рантаймом,
/// не блокирует Kotlin/UI поток.
#[no_mangle]
pub extern "C" fn Java_com_example_streamreceiver_NativeLib_startNetworking(
    mut env: JNIEnv,
    _class:  JClass,
    host:    JString,
    port:    jint,
) {
    let _ = std::panic::catch_unwind(|| {
        let host: String = env
            .get_string(&host)
            .expect("Invalid host string")
            .into();

        let backend = get_or_create_backend();

        std::thread::Builder::new()
            .name("quic-receiver".into())
            .spawn(move || {
                let rt = tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                    .expect("Failed to build tokio runtime");

                rt.block_on(async move {
                    let addr: std::net::SocketAddr = format!("{}:{}", host, port)
                        .parse()
                        .expect("Invalid address format");

                    log::info!("[QUIC] Connecting to {addr}");
                    crate::network::run_quic_receiver(backend, addr).await;
                });
            })
            .expect("Failed to spawn networking thread");
    });
}

/// Остановить декодер и освободить ANativeWindow.
///
/// ОБЯЗАТЕЛЬНО вызывать из `surfaceDestroyed` callback'а SurfaceHolder —
/// до того как Surface будет уничтожен платформой!
#[no_mangle]
pub extern "C" fn Java_com_example_streamreceiver_NativeLib_shutdownBackend(
    _env:   JNIEnv,
    _class: JClass,
) {
    let _ = std::panic::catch_unwind(|| {
        if let Some(backend) = BACKEND.get() {
            backend.lock().unwrap().shutdown();
            log::info!("[JNI] shutdownBackend OK");
        }
    });
}
